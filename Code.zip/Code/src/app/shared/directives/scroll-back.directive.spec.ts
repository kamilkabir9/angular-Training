import { ScrollBackDirective } from './scroll-back.directive';

describe('ScrollBackDirective', () => {
  it('should create an instance', () => {
    const directive = new ScrollBackDirective();
    expect(directive).toBeTruthy();
  });
});
